-- 3dvia.com   --

The zip file chuck_assm.stl.zip contains the following files :
- readme.txt
- chuck_assm.stl


-- Model information --

Model Name : chuck_assm
Author : psaudio
Publisher : psaudio

You can view this model here :
http://www.3dvia.com/content/84976BBA8C9EB082
More models about this author :
http://www.3dvia.com/psaudio


-- Attached license --

A license is attached to the chuck_assm model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
