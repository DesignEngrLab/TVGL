-- 3dvia.com   --

The zip file barrel lock - casing.STL.zip contains the following files :
- readme.txt
- barrel lock - casing.STL


-- Model information --

Model Name : barrel lock - casing.STL
Author : jasoncooper
Publisher : jasoncooper

You can view this model here :
http://www.3dvia.com/content/AA2314A0B28496A8
More models about this author :
http://www.3dvia.com/jasoncooper


-- Attached license --

A license is attached to the barrel lock - casing.STL model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
